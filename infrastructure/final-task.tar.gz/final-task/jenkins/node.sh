#!/bin/bash

for index in a b c
do
  ssh -i /opt/jenkins/devops13-keypair.pem -o StrictHostKeyChecking=no ubuntu@$1-node$index-local.devops13.training.triangu.com docker stop final-task
  ssh -i /opt/jenkins/devops13-keypair.pem -o StrictHostKeyChecking=no ubuntu@$1-node$index-local.devops13.training.triangu.com docker run --name final-task --rm -p 80:8080 -d registry-local.devops13.training.triangu.com:5000/v2/$2
done
