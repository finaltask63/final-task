#!/bin/bash

# Copy configuration, plugins and jobs and all to newly installed Jenkins
echo "Copying pre-defined config"
sudo cp -R /opt/jenkins/home/config.xml \
    /opt/jenkins/home/credentials.xml \
    /opt/jenkins/home/identity.key.enc \
    /opt/jenkins/home/secret.key \
    /opt/jenkins/home/secret.key.not-so-secret \
    /opt/jenkins/home/secrets \
    /opt/jenkins/home/users \
    /opt/jenkins/home/fingerprints \
    /opt/jenkins/home/jobs \
    /opt/jenkins/home/init.groovy.d \
    /opt/jenkins/jenkins-cli.jar \
    /var/lib/jenkins
sudo chown -R jenkins:jenkins /var/lib/jenkins

echo "Starting Jenkins service"
sudo systemctl start jenkins

echo "Sleeping 60 seconds"
sleep 60

# Install plugins
echo "Installing plugins (may take a while)"
for plugin in `cat /opt/jenkins/casc/plugins.txt`
do
  java -jar /opt/jenkins/jenkins-cli.jar -s http://127.0.0.1:8080/ -auth admin:1 install-plugin $plugin
done

# Restart the service
echo "Restarting Jenkins service"
sudo systemctl stop jenkins
export CASC_JENKINS_CONFIG=/opt/jenkins/casc/config.yaml
sudo systemctl start jenkins

# Remove initial instructions
sleep 30
rm -fR /var/lib/jenkins/init.groovy.d
