#!/bin/bash

add-apt-repository --yes --update ppa:ansible/ansible
apt update
#apt upgrade -y
apt install -y ansible
mv /home/ubuntu/final-task/ansible /opt/
mv /home/ubuntu/final-task/registry /opt/
mv /home/ubuntu/final-task/master /opt/
mv /home/ubuntu/final-task/node /opt/
mv /home/ubuntu/final-task/jenkins /opt/
mv /etc/ansible/hosts /etc/ansible/hosts.dist
cp /opt/ansible/hosts /etc/ansible/
mv /etc/ansible/ansible.cfg /etc/ansible/ansible.cfg.dist
cp /opt/ansible/ansible.cfg /etc/ansible/
