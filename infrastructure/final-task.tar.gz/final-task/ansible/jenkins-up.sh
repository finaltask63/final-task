#!/bin/bash

ansible-playbook /opt/ansible/jenkins.yml