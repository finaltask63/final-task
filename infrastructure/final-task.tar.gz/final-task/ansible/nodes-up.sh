#!/bin/bash

ansible-playbook /opt/ansible/node.yml