#!/bin/bash

ansible-playbook /opt/ansible/master.yml