#!/bin/bash

ansible-playbook /opt/ansible/registry.yml